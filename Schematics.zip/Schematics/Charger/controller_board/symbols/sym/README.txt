symbols taken from	/mathews_bobby/gEDA/Control_Board/Working/sym/ 
